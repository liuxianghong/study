.. _reference.feed.generator:

:py:attr:`feed.generator`
=========================

A human-readable name of the application used to generate the feed.


.. rubric:: Comes from

* /atom03:feed/atom03:generator
* /atom10:feed/atom10:generator
* /rdf:RDF/rdf:channel/admin:generatorAgent/@rdf:resource
* /rss/channel/generator


.. seealso::

    * :ref:`reference.feed.generator_detail`
