.. _reference.feed.published_parsed:

:py:attr:`feed.published_parsed`
================================

The date the feed was published, as a standard :program:`Python` 9-tuple.


.. rubric:: Comes from

* /rss/channel/pubDate


.. seealso::

    * :ref:`reference.feed.published`
