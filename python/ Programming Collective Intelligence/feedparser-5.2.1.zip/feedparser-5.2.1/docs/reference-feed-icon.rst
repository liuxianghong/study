:py:attr:`feed.icon`
====================

A URL to a small icon representing the feed.

If this is a relative :abbr:`URI (Uniform Resource Identifier)`, it is
:ref:`resolved according to a set of rules <advanced.base>`.


.. rubric:: Comes from

* /atom10:feed/atom10:icon
